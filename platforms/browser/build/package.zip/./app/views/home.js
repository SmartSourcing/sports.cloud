define(function (require) {

    "use strict";
    var models      = require('app/models/tournament');
    var tpl         = require('text!tpl/tournaments.html');
    var template    = _.template(tpl);

    var tv = Backbone.View.extend( {

        initialize: function () {
            var self = this;
            console.log('view::initialize');
            this.tournaments = new models.Tournaments();            
            //this.tournaments.bind('reset', self.render)
            //this.tournaments.fetch({reset: true});
            this.tournaments.fetch({ success: function(){ self.render(); } });      
        },
        render: function () {

            console.log('view::render');
            //$('#page_content').html(template({data: this.tournaments.data}));
            $('#page_content').html(template({tournaments: this.tournaments.toJSON()}));
            return this;
        }    
    });

    return { TournamentsView: tv };
});