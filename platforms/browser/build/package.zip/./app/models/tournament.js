var app = app || {};


var Tournament = {
    id : -1,
    name : '',
    iphone_logo: ''
}
 