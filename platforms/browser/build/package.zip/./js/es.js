$.i18n.strings['es'] = $.i18n.strings.es = $.extend($.i18n.strings.es, {
    "tournaments": "Torneos de Paintball",
    "add.tournament": "Crea tu propio torneo",
});
