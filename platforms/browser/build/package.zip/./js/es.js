$.i18n.strings['es'] = $.i18n.strings.es = $.extend($.i18n.strings.es, {
    "menu.news": "Noticias grales",
    "menu.about": "Acerca de",
    "menu.language": "Idioma",
    "menu.close": "Cerrar",
    "tournaments": "Torneos de Paintball",
    "add.tournament": "Crea tu propio torneo",
});
