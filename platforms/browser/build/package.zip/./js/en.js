$.i18n.strings['en'] = $.i18n.strings.en = $.extend($.i18n.strings.en, {
    "menu.news": "General news",
    "menu.ss": "About",
    "menu.language": "Language",
    "menu.close": "Close",
    "tournaments": "Paintball Tournaments",        
    "add.tournament": "Create your own tournament",
});