$.i18n.strings['en'] = $.i18n.strings.en = $.extend($.i18n.strings.en, {
    "tournaments": "Paintball Tournaments",        
    "add.tournament": "Create your own tournament",
});